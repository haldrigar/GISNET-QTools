# -*- coding: utf-8 -*-
import os

from qgis.PyQt import uic # type: ignore
from qgis.PyQt.QtWidgets import QDialog, QMessageBox # type: ignore

from ..tools.Config import plugin_config

# Funkcja uic.loadUiType dynamicznesparsowuje plik .ui i przygotowuje klasę bazową interfejsu
FORM_CLASS, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'settings.ui'))

class OknoUstawien(QDialog, FORM_CLASS):
    def __init__(self, parent=None):
        """Konstruktor okna ładowanego z Qt Designera."""

        super().__init__(parent)
        
        # Kluczowa linijka: buduje interfejs narysowany w Qt Designerze
        self.setupUi(self)
        
        # Standardowe przyciski Qt Designera (QDialogButtonBox) automatycznie obsługują akcje
        # Szukamy domyślnego elementu buttonBox z Designera i łączymy sygnały:
        self.buttonBox.accepted.connect(self.akcja_zapisz)
        self.buttonBox.rejected.connect(self.reject)

    def akcja_zapisz(self):
        """Zapisuje zmienione w oknie wartości z powrotem do konfiguracji."""

        plugin_config.data["bufor_odleglosc"] = self.spinBufor.value()
        plugin_config.data["obliview_zoom"] = self.spinZoom.value()
        
        # Próba fizycznego zapisu pliku JSON
        if plugin_config.zapisz():
            self.accept() # Zamknięcie okna z kodem sukcesu (wywoła akcję w GisnetPlugin)
        else:
            QMessageBox.critical(self, "Błąd", "Nie udało się zapisać pliku konfiguracji JSON!")