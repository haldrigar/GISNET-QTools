# -*- coding: utf-8 -*-
import os

from qgis.PyQt import uic
from qgis.PyQt.QtWidgets import QDialog, QMessageBox, QCheckBox 
from qgis.core import Qgis
from qgis.PyQt.QtWidgets import QButtonGroup 

from ..tools.Config import plugin_config

# Funkcja uic.loadUiType dynamicznesparsowuje plik .ui i przygotowuje klasę bazową interfejsu
FORM_CLASS, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'settings.ui'))

class OknoUstawien(QDialog, FORM_CLASS):

    # ===============================================================================================================================================
    def __init__(self, parent=None):
        """Konstruktor okna ładowanego z Qt Designera."""

        super().__init__(parent)
        
        # Kluczowa linijka: buduje interfejs narysowany w Qt Designerze
        self.setupUi(self)
        
        # Standardowe przyciski Qt Designera (QDialogButtonBox) automatycznie obsługują akcje
        # Szukamy domyślnego elementu buttonBox z Designera i łączymy sygnały:
        self.buttonBox.accepted.connect(self.akcja_zapisz)
        self.buttonBox.rejected.connect(self.reject)

    # ===============================================================================================================================================
    def wczytaj_baze_tekstowa(self):
        """Wczytuje plik Obliview.cfg i parsuje go do słownika."""

        self.plugin_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
        
        sciezka_pliku = os.path.join(self.plugin_dir, 'tools', 'Obliview.cfg')
        
        
        # Używamy encoding='utf-8', aby prawidłowo obsłużyć polskie znaki (ń, ś)
        with open(sciezka_pliku, 'r', encoding='utf-8') as f:
            for linia in f:
                linia = linia.strip()
                # Pomijamy puste linie i te, które nie zawierają średnika
                if linia and ';' in linia:
                    # split(';', 1) dzieli linię tylko na 2 części (w razie gdyby w URL był średnik)
                    miasto, url = linia.split(';', 1)
                    self.slownik_portali[miasto.strip()] = url.strip()


    # ===============================================================================================================================================
    def akcja_zapisz(self):
        """Zapisuje zmienione w oknie wartości z powrotem do konfiguracji."""

        self.slownik_portali_obliview = {}

        plugin_config.zapisz()
        self.accept() # Zamyka okno dialogowe z wynikiem QDialog.Accepted
